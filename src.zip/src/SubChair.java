/**
 * Created by Yeonil on 4/22/14.
 */
public class SubChair extends Reviewer {

}
