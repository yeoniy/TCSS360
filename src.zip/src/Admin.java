/**
 * Created by Yeonil on 4/22/14.
 */

import java.util.ArrayList;

/**
 * used for creating accounts and editting privledges,  assigning program chair.
 */
public class Admin extends User {
    public Admin(String name, String id, String password) {
        super(name, id, password, Type.ADMIN);
    }

    public boolean addUser(ArrayList<User> users, User user) {
        users.add(new User(user));
        return true;
    }

    public void changePriveledge(User user, Type t) {
        // Create new whatever, author, review, etc.
    }
}
