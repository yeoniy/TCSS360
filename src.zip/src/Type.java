/**
 * Created by Yeonil on 4/22/14.
 */
public enum Type {
    AUTHOR, REVIEWER, SUBCHAIR, PROCHAIR, ADMIN
}
