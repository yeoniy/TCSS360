/**
 * Created by Yeonil on 4/22/14.
 */
public class Reviewer extends Author {

}
