import java.util.Date;

/**
 * Created by Yeonil on 4/22/14.
 */
public class Conference {
    private String name;
    private Date date;
    private String id;

    public Conference (String name, Date date, String id) {
        this.name = name;
        this.date = date;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
